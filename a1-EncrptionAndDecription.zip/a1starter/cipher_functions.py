# Functions for running an encryption or decryption.
# The values of the two jokers.
JOKER1 = 27
JOKER2 = 28

# Write your functions here:
def clean_message(input_string):
    '''(str) -> str
    Return a copy of the message that includes only its alphabetical
    characters, where each of those characters has been converted to
    uppercase.
    REQ: one line of the text
    >>> clean_message('hello world!')
    'HELLOWORLD'
    '''
    # set a new string to contain the pure alphabetical character
    alphabetic_str = ''
    # loop through every word in the input_string and only return its
    # alphabetical characters
    for next_letter in input_string:
        if (next_letter.isalpha()):
            alphabetic_str += next_letter
    result = alphabetic_str.upper()
    # return the upper case characters
    return result


def encrypt_letter(achar, key_stream_value):
    '''(str, int) -> str
    Return the character which achar is converted to number and is added by the
    corresponding key_stream_value, modulo 26 and then conterted the number to
    it.
    REQ: the achar must be a single character
    >>> encrypt_letter('A', 6)
    'G'
    '''
    # create a new dictionary to place the character and number
    dictionary = {}
    alphabetic = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z'
    alphabetic_list = alphabetic.split()
    # loop through every number and character let character and number
    # corresponding each other according to alphabet but start with 0
    for i in range(26):
        dictionary[i] = alphabetic_list[i]
        dictionary[alphabetic_list[i]] = i
    # add key_stream_value and the corresponding number of the character
    # together
    result = dictionary[achar] + key_stream_value
    # modulo the result by 26
    if (result > 25):
        result = result - 26
    else:
        result = result
    # return the result which is the corresponding character of the number
    return dictionary[result]


def decrypt_letter(achar, key_stream_value):
    '''(str, int) -> str
    Return the character which achar is converted to number and subtract by the
    corresponding key_stream_value, modulo 26 and then conterted the number to
    it.
    REQ: achar must be a single upper case character
    >>> decrypt_letter('B', 9)
    'S'
    '''
    # create a new dictionary to place the character and number
    dictionary = {}
    alphabetic = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z'
    alphabetic_list = alphabetic.split()
    # loop through every number and character let character and number
    # corresponding each other according to alphabet but start with 0
    for i in range(26):
        dictionary[i] = alphabetic_list[i]
        dictionary[alphabetic_list[i]] = i
    result = dictionary[achar] - key_stream_value
    if (result < 0):
        result += 26
    else:
        result = result
    return dictionary[result]


def swap_cards(card_num, index):
    '''(list of int, int) -> NoneType
    Swap the number at the index with the number that follows it. If the card
    at the index is the last in the list, swap that number with the top number.
    REQ: 0 <= index <= len(deck_of_card) - 1
    REQ: card_num must be list of 28 different digits within range 28
    >>>  a = [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 3, 6, 9, 12, 15, 18, 21, 24,
    27, 2, 5, 8, 11, 14, 17, 20, 23, 26,]
    >>> swap_cards(a, 4)
    >>> print(a)
    [1, 4, 7, 10, 16, 13, 19, 22, 25, 28, 3, 6, 9, 12, 15, 18, 21, 24,
    27, 2, 5, 8, 11, 14, 17, 20, 23, 26,]
    '''
    clone_card = card_num[:]
    if (index <= len(card_num) - 2):
        card_num[index] = clone_card[index + 1]
        card_num[index + 1] = clone_card[index]
    else:
        card_num[1] = clone_card[index]
        card_num[2:] = clone_card[1:index]
        

def move_joker_1(card_num):
    '''(list of int) -> NoneType
    Swap the joker_1 in card-num with its following.
    REQ: card_num must be list of 28 different digits within range 28
    >>> a = [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 3, 6, 9, 12, 15, 18, 21, 24,
    27, 2, 5, 8, 11, 14, 17, 20, 23, 26,]
    >>> move_joker_1(a)
    >>> print(a)
    [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 3, 6, 9, 12, 15, 18, 21, 24, 2, 27,
    5, 8, 11, 14, 17, 20, 23, 26]
    '''
    index = card_num.index(JOKER1)
    swap_cards(card_num, index)


def move_joker_2(card_num):
    '''(list of int) -> NoneType
    Move the joker_2 2 cards down.
    REQ: card_num must be list of 28 different digits within range 28
    >>> a = [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 3, 6, 9, 12, 15, 18, 21, 24,
    27, 2, 5, 8, 11, 14, 17, 20, 23, 26,]
    >>> move_joker_2(a)
    >>> print(a)
    [1, 4, 7, 10, 13, 16, 19, 22, 25, 3, 6, 28, 9, 12, 15, 18, 21, 24, 27, 2,
    5, 8, 11, 14, 17, 20, 23, 26]
    '''
    index = card_num.index(JOKER2)
    swap_cards(card_num, index)
    index = card_num.index(JOKER2)
    swap_cards(card_num, index)


def triple_cut(card_num):
    '''(list of int) -> NoneType
    Swap the cards above the first joker (the joker closest to the
    top of the deck) with the cards below the second joker.
    REQ: card_num must be list of 28 different digits within range 28
    >>> a = [1, 4, 7, 10, 13, 16, 19, 22, 25, 26, 3, 6, 9, 12, 15, 18, 21, 24,
    28, 2, 5, 8, 11, 14, 17, 20, 23, 27]
    >>> triple_cut(a)
    >>> print(a)
    [28, 2, 5, 8, 11, 14, 17, 20, 23, 27, 1, 4, 7, 10, 13, 16, 19, 22, 25, 26,
    3, 6, 9, 12, 15, 18, 21, 24]
    '''
    clone_card_num = card_num[:]
    index_J1 = card_num.index(JOKER1)
    index_J2 = card_num.index(JOKER2)
    if (index_J1 < index_J2):
        card_num[:index_J1] = clone_card_num[index_J2 + 1:]
        index_J2 = card_num.index(JOKER2)
        card_num[index_J2 + 1:] = clone_card_num[:index_J1]
    else:
        card_num[:index_J2] = clone_card_num[index_J1 + 1:]
        index_J1 = card_num.index(JOKER1)
        card_num[index_J1 + 1:] = clone_card_num[: index_J2]


def insert_top_to_bottom(card_num):
    '''(list of int) -> NoneType
    Put first N card, which N is the value that is equal to the last card's
    value, in front of the last card.
    REQ: card_num must be list of 28 different digits within range 28
    >>> a = [1, 4, 7, 10, 13, 16, 19, 22, 25, 26, 3, 6, 9, 12, 15, 18, 21, 24,
    28, 2, 23, 8, 11, 14, 17, 20, 27, 5]
    >>> insert_top_to_bottom(a)
    >>> print(a)
    [16, 19, 22, 25, 26, 3, 6, 9, 12, 15, 18, 21, 24, 28, 2, 23, 8, 11, 14, 17,
    20, 27, 1, 4, 7, 10, 13, 5]
    '''
    clone_card_num = card_num[:]
    N = card_num[-1]
    if (N <27):
        card_num[:-1] = clone_card_num[N:-1]
        card_num[-1:] = clone_card_num[:N] + [N]
    else:
        card_num = card_num


def get_card_at_top_index(card_num):
    '''(list of int) -> int
    Return a integer that is at the position of where the first value is.
    if the final value is a joker, do several functions again until extract
    the number between 1 to 26.
    REQ: card_num must be list of 28 different digits within range 28
    >>> a = [18, 4, 7, 10, 13, 16, 19, 22, 25, 26, 3, 6, 9, 12, 15, 1, 21, 24,
    28, 2, 23, 8, 11, 14, 17, 20, 27, 5]
    >>> get_card_at_top_index(a)
    28
    '''
    N = card_num[0]
    if (N <= JOKER1):
        return card_num[N]
    return card_num[JOKER1]


def get_next_value(card_num):
    '''(list of int) -> int
    Return next  potential key value according to the all five steps of the
    algorithm.
    REQ: card_num must be list of 28 different digits within range 28
    >>> a = [18, 4, 7, 10, 13, 16, 19, 22, 25, 26, 3, 6, 9, 12, 15, 1, 21, 24,
    28, 2, 23, 8, 11, 14, 17, 20, 27, 5]
    >>> get_next_value(a)
    21
    '''
    move_joker_1(card_num)
    move_joker_2(card_num)
    triple_cut(card_num)
    insert_top_to_bottom(card_num)
    return get_card_at_top_index(card_num)


def get_next_keystream_value(card_num):
    ''' (list of int) -> int
    Return a valid keystream value that is in the range of 26
    REQ: card_num must be list of 28 different digits within range 28
    >>> a = [18, 4, 7, 10, 13, 16, 19, 22, 25, 26, 3, 6, 9, 12, 15, 1, 21, 24,
    28, 2, 23, 8, 11, 14, 17, 20, 27, 5]
    >>> get_next_keystream_value(a)
    21
    '''
    potential_value = get_next_value(card_num)
    while (potential_value == JOKER1) or (potential_value == JOKER2):
        potential_value = get_next_value(card_num)
    return potential_value


def process_message(card_num, message, order):
    '''(list of int, str, str) -> str
    Return the string according to the order. If the order is encrypt then
    return the encryption of the card_num. If the order is decrypt then return
    the decryption of the card_num.
    REQ: card_num must be list of 28 different digits within range 28
    REQ: the input of the order should be either 'e' (to encrypt) or
    'd'(to decrypt)
    >>> a = [18, 4, 7, 10, 13, 16, 19, 22, 25, 26, 3, 6, 9, 12, 15, 1, 21, 24,
    28, 2, 23, 8, 11, 14, 17, 20, 27, 5]
    >>> b = 'this!'
    >>> process_message(a,b,'e')
    'OZEC'
    '''
    new_message = clean_message(message)
    keystream_value = []
    for i in range(len(new_message)):
        keystream_value.append(get_next_keystream_value(card_num))
    each_letter = []
    for each_char in new_message:
        each_letter.append(each_char)
    if (order == 'e'):
        result = ''
        for i in range(len(new_message)):
            result += encrypt_letter(each_letter[i], keystream_value[i])
    elif (order == 'd'):
        result = ''
        for i in range(len(new_message)):
            result += decrypt_letter(each_letter[i], keystream_value[i])
    return result


def process_messages(card_num, messages, order):
    '''(list of int, list of str, str) -> list of str
    Return a list of messages which is encrypted or decrypted according to the
    order 'to decrypt' or 'to encrypt'
    REQ: card_num must be list of 28 different digits within range 28
    REQ: order should be either 'e'(to encrypt)or 'd'(to decrypt)
    >>> a = [18, 4, 7, 10, 13, 16, 19, 22, 25, 26, 3, 6, 9, 12, 15, 1, 21, 24,
    28, 2, 23, 8, 11, 14, 17, 20, 27, 5]
    >>> b = ['this!', 'That@', 'haha']
    >>> process_messages(a, b,'e')
    ['OZEC', 'HHPY', 'LWKF']
    '''
    if (order == 'e'):
        list_messages = []
        for message in messages:
            list_messages.append(process_message(card_num, message, order))
    if (order == 'd'):
        list_messages = []
        for message in messages:
            list_messages.append(process_message(card_num, message, order))
    return list_messages


def read_messages(file):
    '''(file open for reading) -> list of string
    Return a list of message in the file which contains one message per line.
    REQ: file should be open for reading
    '''
    list_messages = []
    content = file.readlines()
    lines = len(content)
    for i in range(lines):
        content[i] = content[i].strip()
        list_messages.append(content[i])
    return list_messages


def read_deck(file):
    '''(file open for reading) -> list of int
    Return a list of number in the file which contains the number 1 to 28 in
    some order.
    REQ: file should be open for reading
    '''
    list_numbers = []
    content = file.readlines()
    lines = len(content)
    for i in range(lines):
        line_numbers = content[i].strip().split()
        for each_number in line_numbers:
            list_numbers.append(int(each_number))
    return list_numbers
